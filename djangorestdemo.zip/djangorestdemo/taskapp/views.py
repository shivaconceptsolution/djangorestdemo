from .models import UserInfo,Client,Project
from rest_framework import viewsets
from rest_framework import permissions
from taskapp.serializers import UserInfoSerializer,ClientSerializer,ProjectSerializer

class UserInfoViewSet(viewsets.ModelViewSet):
    """
    API to fetch, update, delete and find all user's record.
    """
    queryset = UserInfo.objects.all()
    serializer_class = UserInfoSerializer
   
class ClientViewSet(viewsets.ModelViewSet):
    """
    API to fetch, update, delete and find all client record.
    """
    queryset = Client.objects.all()
    serializer_class = ClientSerializer

class ProjectViewSet(viewsets.ModelViewSet):
    """
    API to fetch, update, delete and find all project record.
    """
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer

class ProjectUserInfoViewSet(viewsets.ModelViewSet):
    """
    API to find project based on project.
    """
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer
    