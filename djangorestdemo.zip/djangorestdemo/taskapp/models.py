from django.db import models
class UserInfo(models.Model):
    name = models.CharField(max_length=10)
   
    def __str__(self):
        return "name is "+self.name

class Client(models.Model):
    clientname = models.CharField(max_length=10)
    createdat = models.DateTimeField(auto_now_add=True)
    createdby = models.CharField(max_length=20)
    def __str__(self):
        return "Client Name is "+self.clientname + " Created at "+str(self.createdat) + " Created by "+self.createdby


class Project(models.Model):
	client = models.ForeignKey(Client, on_delete=models.CASCADE)
	userinfo = models.ForeignKey(UserInfo, on_delete=models.CASCADE)
	projectname = models.CharField(max_length=10)
	createdat = models.DateTimeField(auto_now_add=True)
	createdby = models.CharField(max_length=20)
	def __str__(self):
		return "Project name is "+self.projectname